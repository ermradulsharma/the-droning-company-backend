<?php

namespace App\Http\Controllers\Api\V1;

use App\Models\ContentPage;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Database\Eloquent\Collection;

class AboutApiController extends Controller
{
    /**
     * About .
     * Get Method
     * If everything is okay, you'll get a `200` OK response with data.
     *
     * Otherwise, the request will fail with a `404` error, and a response about data not found!
     *
     *
     * <aside class="notice">basepath/api/v1/about.</aside>
     *
     *
     * @return \Illuminate\Http\Response
     *
     * @response
     *  {
            "stausCode": 200,
            "message": "about fetch successfully",
            "data": [
                {
                    "title": "Specializing in Drone Services, and Aerial Photography",
                    "page_text": "<p>There are many variations of passages of lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly.\n</p>"
                }
            ]
        }
     *
     *
     * @response status=404 {
            "stausCode": 404,
            "message": "about data not found!",
            "data": []
        }
     *
     *
     *
     */

    public function index()
    {
        $about = ContentPage::query()->select('title','page_text')
            ->where('id', 1)->get();

        if ($about->isEmpty()) {
            return response()->json([
                'stausCode' =>404,
                'message' => 'about data not found!',
                'data' =>[]
            ])->setStatusCode(404);
        }

        return response()->json([
             'stausCode'=>Response::HTTP_OK,
             'message' => 'about fetch successfully',
             'data'=>$about
        ])->setStatusCode(Response::HTTP_OK);
    }
}
