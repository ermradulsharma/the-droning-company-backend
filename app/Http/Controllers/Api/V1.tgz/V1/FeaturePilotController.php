<?php

namespace App\Http\Controllers\Api\V1;

use App\Models\PilotSkills;
use App\Models\PilotAddress;
use App\Models\PilotProfile;
use Illuminate\Http\Request;
use App\Services\SkillService;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

class FeaturePilotController extends Controller
{
    /**
     * featured Pilot Profile.
     *
     * If everything is okay, you'll get a `200` OK response with data.
     *
     * Otherwise, the request will fail with a `404` error, and a response featured pilot not found!
     *
     *
     * <aside class="info">This api will used in <br> 1. Blog Listing <br> 2. Blog Detail <br>3.Category Page</aside>
     *
     * @param \Illuminate\Http\Request  $request
     * @param $id required
     * @return \Illuminate\Http\Response
     *
     * @response  {
            "stausCode": 200,
            "message": "featured Profile fetch successfully",
            "data": [
                {
                    "pilot_profile_id": 691,
                    "user_id": 184,
                    "name": "Devin Ullrich",
                    "title": "itaque",
                    "slug": "omnis-ad-sunt-consequatur-dolorum-aut-quia-quis",
                    "short_description": "<p>magnam<\/p>",
                    "image": "http:\/\/local.drone\/pilotseed.png",
                    "skills": "Videography,Video Editing"
                },
                {
                    "pilot_profile_id": 692,
                    "user_id": 185,
                    "name": "Maximus Keeling",
                    "title": "eveniet",
                    "slug": "eos-quae-iure-necessitatibus-excepturi-delectus-alias-aut",
                    "short_description": "dolorem",
                    "image": "http:\/\/local.drone\/pilotseed.png",
                    "skills": "Videography"
                },
              ]

              }

     *
     * @response status=404 {
            "stausCode": 404,
            "message": "featured Profile not found!",
            "data": []
        }

    */
    public function index(Request $request)
    {
        $profiles=PilotProfile::with('userSkill')
                            ->latest()
                            ->featured()
                            ->active()
                            ->take(4)
                            ->get();

        if ($profiles->isEmpty()) {
            return response()->json([
                'stausCode' =>404,
                'message' => 'featured Profile not found!',
                'data' =>[]
            ])->setStatusCode(404);
        }
   
        $data=[];
        foreach ($profiles as $key => $value) {
            $data[]=[
                'pilot_profile_id'=>$value->id,
                'user_id'=>$value->user_id,
                'name'=>$value->users->name,
                'title'=>$value->title,
                'slug'=>$value->slug,
                'short_description'=>$value->short_description,
                'image'=>asset($value->image),
                'skills'=>(new SkillService())->pilot($value->id),
                'is_insured'=>$value->is_insured
          ];
        }

        return response()->json([
                         'stausCode'=>Response::HTTP_OK,
                         'message' => 'featured Profile fetch successfully',
                         'data'=>$data
                     ])->setStatusCode(Response::HTTP_OK);
    }

    /**
    * Home Featured pilot Profile.
    *
    * If everything is okay, you'll get a `200` OK response with data.
    *
    * Otherwise, the request will fail with a `404` error, and a response recent featured blog post not found!
    *
    *
    * @param \Illuminate\Http\Request  $request
    * @param $id required
    * @return \Illuminate\Http\Response
    *
    * @response  {
           "stausCode": 200,
           "message": "featured Profile fetch successfully",
           "data": [
               {
                   "pilot_profile_id": 691,
                   "user_id": 184,
                   "name": "Devin Ullrich",
                   "title": "itaque",
                   "slug": "omnis-ad-sunt-consequatur-dolorum-aut-quia-quis",
                   "short_description": "<p>magnam<\/p>",
                   "image": "http:\/\/local.drone\/pilotseed.png",
                   "skills": "Videography,Video Editing",
                   "no_of_jobs": 10,
                   "hourly_rate": 10
               }
           ]
       }
     *
     * @response status=404 {
           "stausCode": 404,
           "message": "featured Profile not found!",
           "data": []
       }

    */
    public function homeFeatured(Request $request)
    {
        $profiles=PilotProfile::with(['userSkill','hourlyRate'])
                            ->homeFeatured()
                            ->active()
                            ->take(1)
                            ->latest()
                            ->get();

        if ($profiles->isEmpty()) {
            return response()->json([
                'stausCode' =>404,
                'message' => 'featured Profile not found!',
                'data' =>[]
            ])->setStatusCode(404);
        }
   
        $data=[];
        foreach ($profiles as $key => $value) {
            $data[]=[
                'pilot_profile_id'=>$value->id,
                'user_id'=>$value->user_id,
                'name'=>$value->users->name,
                'title'=>$value->title,
                'slug'=>$value->slug,
                'short_description'=>$value->short_description,
                'image'=>asset($value->image),
                'skills'=>(new SkillService())->pilot($value->id),
                'no_of_jobs'=>0,
                'hourly_rate'=>$value->hourlyRate->rate ?? '0',
                'is_insured'=>$value->is_insured
          ];
        }

        return response()->json([
                         'stausCode'=>Response::HTTP_OK,
                         'message' => 'featured Profile fetch successfully',
                         'data'=>$data
                     ])->setStatusCode(Response::HTTP_OK);
    }

    /**
    * category pilot feature.
    *
    * If everything is okay, you'll get a `200` OK response with data.
    *
    * Otherwise, the request will fail with a `404` error, and a response recent featured blog post not found!
    *
    *
    * @param \Illuminate\Http\Request  $request
    * @param $id required
    * @return \Illuminate\Http\Response
    *
    * @response  {
           "stausCode": 200,
           "message": "featured Profile fetch successfully",
           "data": [
               {
                   "pilot_profile_id": 691,
                   "user_id": 184,
                   "name": "Devin Ullrich",
                   "title": "itaque",
                   "slug": "omnis-ad-sunt-consequatur-dolorum-aut-quia-quis",
                   "short_description": "<p>magnam<\/p>",
                   "image": "http:\/\/local.drone\/pilotseed.png",
                   "skills": "Videography,Video Editing",
                   "no_of_jobs": 10,
                   "hourly_rate": 10
               }
           ]
       }
     *
     * @response status=404 {
           "stausCode": 404,
           "message": "featured Profile not found!",
           "data": []
       }

    */

    public function categoryFeature(Request $request)
    {
        $profiles=PilotProfile::query();
        
        $profile_count=$profiles->count();

        
        if ($request->has('q') && $request->input('q')!='') {
            $decode_string=json_decode($request->input('q'));
            $city= $decode_string->city ?? '';
            $state= $decode_string->state ?? '';
            $country= $decode_string->country ?? '';
            $address= $decode_string->address ?? '';

            $pilot_profile_id = PilotAddress::query()
                                     ->join('pilot_profile', 'pilot_address.pilot_profile_id', '=', 'pilot_profile.id')
                                    ->whereLike('city', $city)
                                    ->orWhere(function ($query) use ($state) {
                                        $query->whereHas('state', fn ($q) =>$q->whereLike('name', $state));
                                    })
                                    ->orWhere(function ($country_query) use ($country) {
                                        $country_query->whereHas('countryRelation', fn ($q1) =>$q1->whereLike('name', $country));
                                    })
                                     ->orWhere(function ($address_query) use ($address) {
                                         $address_query->whereLike('address_line1', $address);
                                     })
                                    ->select('pilot_profile_id')
                                    ->distinct('pilot_profile_id')
                                    ->get()
                                    ->pluck('pilot_profile_id');

            $profiles=$profiles->whereIn('id', $pilot_profile_id);
        }


        if ($request->has('skill') && $request->input('skill')!='') {
            $skilled_profile=\DB::table('pilot_skills')
                            ->where('skill_id', $request->input('skill'))
                            ->get()
                            ->pluck('pilot_profile_id');


            $profiles=$profiles->whereIn('id', $skilled_profile);
        }
        $profile_count=$profiles->count();

        if ($request->has('page')) {
            $page=$request->input('page');
            $page=$page-1;
            $offset=$page*5;
            $profiles=$profiles->offset($offset);
        }
        $profiles=$profiles->take(4)->latest()->get();

 

        if ($profiles->isEmpty()) {
            return response()->json([
                'stausCode' =>404,
                'message' => 'profiles not found!',
                'data' =>[]
            ])->setStatusCode(404);
        }
       

        $master=[];
        foreach ($profiles as $key=>$value) {
            $data=$value;
            $data['name']=$value->users->name;
            $data['description']=\Str::limit($value->description, 150);
            $data['skills']=(new SkillService())->pilot($value->id);
            unset($data['users']);

            $master[]=$data;
        }

        return response()->json([
                         'stausCode'=>Response::HTTP_OK,
                         'message' => 'profile fetch successfully',
                         'profile_count'=>$profile_count,
                         'data'=>$master,
                     ]);
    }
}
